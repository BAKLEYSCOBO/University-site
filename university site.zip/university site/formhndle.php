<?php
$name = $_POST['name'];
$visitor_email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$enail_from = 'petergodwin432@gmail.com'

$email_subject = 'New Form Submision'

$email_body = 'User Name: $name.\n'
               'User Email: $visitor_email.\'
               'subject: $subject.\'
               'User Message: $message.\'

$to =                
                



?>